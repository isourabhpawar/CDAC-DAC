exports.addition=function(a,b){
    return a+b;
}

exports.factorial=function(x){
    f=1;
    for(i=1;i<=x;i++){
        f=f*i;
    }
    return f;
}