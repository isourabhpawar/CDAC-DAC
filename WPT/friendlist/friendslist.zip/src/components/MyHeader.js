import "./MyHeader.css";
const MyHeader=()=>{
     return(
        <div>
            <h1 className="myclass">Friends List</h1>
        </div>
     )
}

export default MyHeader;