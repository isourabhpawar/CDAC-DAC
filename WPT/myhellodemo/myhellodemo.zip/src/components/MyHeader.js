var MyHeader=()=>{
    var name="Kishori";
    return(
        <div>
            <h1>Hello from {name} in functional component</h1>
            <h3>Welcome to react programming</h3>
        </div>
    )
}

export default MyHeader;
   