exports.cArea=function(r){
    return 3.14*r*r;
};
exports.cCircumference=function(r){
    return 2*3.14*r;
};
exports.cDiameter=function(r){
    return 2*r;
}