﻿using Microsoft.EntityFrameworkCore;
using WebApp.Models;

namespace WebApp.data
{
    public class MyDbContext:DbContext 
    {
        public DbSet<Product> products { get; set; }
        public MyDbContext(DbContextOptions<MyDbContext> options) : base(options) { }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
        }
    }
}
