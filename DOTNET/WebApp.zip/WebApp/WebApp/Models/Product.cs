﻿using Microsoft.Build.Framework;

using System.ComponentModel.DataAnnotations;

namespace WebApp.Models
{
    public enum Category
    {
        WHISKY,STING
    }
    public class Product
    {
        [Key]
           public int Id { get; set; }
  
        public String Name { get; set; }
        [EnumDataType(typeof(Category))]  
        
        public Category Category { get; set; }
        [DataType(DataType.Date)]
        public DateTime CreatedDate { get; set; }

    }
}
