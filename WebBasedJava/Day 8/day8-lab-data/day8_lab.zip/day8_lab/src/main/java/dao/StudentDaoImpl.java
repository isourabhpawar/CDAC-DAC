package dao;

import pojos.Student;
import org.hibernate.*;
import static utils.HibernateUtils.getFactory;

import java.io.Serializable;

public class StudentDaoImpl implements StudentDao {

	@Override
	public String registerNewStudent(Student student) {
		String mesg="Registering student failed!!!!";
		// 1. get session from SF
		Session session=getFactory().getCurrentSession();
		//2. begin a tx
		Transaction tx=session.beginTransaction();
		try {
			 Serializable id= session.save(student);
			tx.commit();
			mesg="Student registered successfully with id="+id;
		} catch (RuntimeException e) {
			if(tx != null)
				tx.rollback();
			throw e;
		}
		return mesg;
	}

}
